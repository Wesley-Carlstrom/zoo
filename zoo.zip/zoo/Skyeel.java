public class Skyeel extends Animal
implements Flying
{
    public Skyeel() {
        this(" an eel like flying creature" , "common along the coastal regions of Roshar");
    }

    public Skyeel(String name, String description) {
        super(name, description);
    }

    @Override

    public String eat() {
        return("eats cremlings and flying bugs ");
    }

    @Override
    public String makeNoise() {
        return("chull quietly");
    }

    @Override
    public String fly() {
        return "slithers through the air, almost spirit like";
    }
}

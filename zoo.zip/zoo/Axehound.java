public class Axehound extends Animal
implements Walking
{
    public Axehound() {
        this(" an axehound of Roshar" , "domesticated and kept as pets in almost all parts of the world");
    }

    public Axehound(String name, String description) {
        super(name, description);
    }

    @Override

    public String eat() {
        return("gobbles on meat and bone");
    }

    @Override
    public String makeNoise() {
        return("barks annoyingly");
    }

    @Override
    public String walk() {
        return "clumsily run ";
    }
}

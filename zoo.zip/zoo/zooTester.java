import java.util.List;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;
import java.util.Random;
import java.util.Scanner;
/**
 * Write a description of class zooTester here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class zooTester
{
    public static boolean highstorm; 
    public static int randomNumber;
    public static int randomNumber2;
    public static boolean findShelter;
    
    public static void main(String[] args ) throws InterruptedException 
    {
        int min = 5;
        int max = 10;
        List<Animal> animals = new ArrayList<Animal>();
        List<Animal> CosmereAnimals = new ArrayList<Animal>();
        System.out.println("Welcome to my wonderous zoo, now including specimines from the cosmere! Based on books from Brandon Sandersons stormlight books\n");
        System.out.println("building zoo, please wait");
        delayDots(3);
        System.out.println("Hiring Zookeepers and buying Parshmen");
        delayDots(3);
        System.out.println("Adding Aminals");
        populateAnimals(animals);
        populateCosmereAnimals(CosmereAnimals);
        delayDots(3);
        getRandomNumber(min, max);
        System.out.println(randomNumber);

        Scanner in = new Scanner(System.in);
        String text = in.nextLine();
        String msg = "";


        while(!text.equals("leave")) {
            switch(text) {
                case "help":
                msg = "you could visit cages, look around, look up at the flying animals,";
                break;
                case "visit cages" :
                msg = visitCages(animals);
                break;
                case"look Aound":
                msg = lookAround(animals);
                break;
                case"look up":
                msg = lookUp(animals);
                break;
                case"look at water animls":
                msg = lookAtWater(animals);
                case"visit cosmere cages":
                msg= visitCages(CosmereAnimals);
                break;
                case"look at the ground cosmere animals":
                msg = lookAround(CosmereAnimals);
                break;
                case"look at the fying cosmere animals":
                msg = lookUp(CosmereAnimals);
                break;
                case"visit stormwardens":
                highstorm();
                break;
                case"find shelter":
                findShelter();
                break;
                default : msg = "";
            }
            System.out.println("\n" + msg);
            delayDots();
            System.out.println("what now");
            text = in.nextLine();
        }
    }

    public static void populateAnimals(List<Animal> animals) {
        nakedMoleRats a1 = new nakedMoleRats();
        animals.add(a1);

        FleshMonster a2 = new FleshMonster();
        animals.add(a2);

        IronTarkus a3 = new IronTarkus();
        animals.add(a3);

        LR57CombatDroid a4 = new LR57CombatDroid();
        animals.add(a4);

        Platypus a5 = new Platypus();
        animals.add(a5);

        Walter a6 = new Walter();
        animals.add(a6);

        Droid a7 = new Droid();
        animals.add(a7);

        Phish a8 = new Phish();
        animals.add(a8);

        Bunny a9 = new Bunny();
        animals.add(a9);

        RedPanda a10 = new RedPanda();
        animals.add(a10);

        GoldFish a11 = new GoldFish();
        animals.add(a11);

        Bokoblin a12 = new Bokoblin();
        animals.add(a12);

        Llama a13 = new Llama();
        animals.add(a13);

        Bigfoot a14 = new Bigfoot();
        animals.add(a14);

        SunBear a15 = new SunBear();
        animals.add(a15);

    }

    public static void populateCosmereAnimals(List<Animal> CosmereAnimals) {
        Chasmfiend b1 = new Chasmfiend();
        CosmereAnimals.add(b1);

        Whitespine b2 = new Whitespine();
        CosmereAnimals.add(b2);

        Greatshell b3 = new Greatshell();
        CosmereAnimals.add(b3);

        Axehound b4 = new Axehound();
        CosmereAnimals.add(b4);

        Skyeel b5 = new Skyeel();
        CosmereAnimals.add(b5);
    }

    public static String delayDots(List<Animal> animals) {
        String msg = "";
        for(Animal a : animals) {
            msg += a.getName() + ":\n" + a.getDescription() + "\n";
        }
        return msg;
    }

    public static void delayDots(int dotAmount) throws InterruptedException {
        for(int i=0; i<dotAmount; i++) {
            TimeUnit.SECONDS.sleep(1);
            System.out.print(".");

        }
        System.out.println();
    }

    public static void delayDots() throws InterruptedException {
        delayDots(3);
    }

    public static String visitCages(List<Animal> animals) {
        String msg = "";
        for(Animal a : animals) {
            msg += a.getName() + ":\n  " + a.getDescription() + "\n";
        }
        return msg;
    } 

    public static String lookAround(List<Animal> animals) {
        String msg = "";
        for(Animal a : animals) {
            if(a instanceof Walking) {
                Walking w = (Walking)a;
                msg += a.getName() + ": \n      " + w.walk() + "\n";
            }
        }
        return msg;
    } 

    public static String lookAtWater(List<Animal> animals) {
        String msg = "";
        for(Animal a : animals) {
            if(a instanceof Swimming) {
                Swimming s = (Swimming)a;
                msg += a.getName() + ": \n      " + s.swim() + "\n";
            }
        }
        return msg;
    } 

    public static String lookUp(List<Animal> animals) {
        String msg = "";
        for(Animal b : animals  ) {
            Flying f = (Flying)b;
            msg += b.getName() + ": \n" + f.fly() + "\n";
        }
        return msg;
    }

    public static String visitCosmereCages(List<Animal> CosmereAnimals) {
        String msg = "";
        for(Animal b :CosmereAnimals) {
            msg += b.getName() + ":\n  " + b.getDescription() + "\n";
        }
        return msg;
    } 

    public static String CosmerelookUp(List<Animal> CosmereAnimals) {
        String msg = "";
        for(Animal b : CosmereAnimals  ) {
            Flying f = (Flying)b;
            msg += b.getName() + ": \n" + f.fly() + "\n";
        }
        return msg; 
    }

    public static String CosmerelookAround(List<Animal> CosmereAnimals) {
        String msg = "";
        for(Animal a : CosmereAnimals) {
            if(a instanceof Walking) {
                Walking w = (Walking)a;
                msg += a.getName() + ": \n      " + w.walk() + "\n";
            }
        }
        return msg;
    } 

    public static int getRandomNumber(int min, int max) {
        Random randomNumber = new Random();
	return randomNumber.nextInt((max - min) + 1) + min;
    }

    private static int RandomNumber2(int min, int max) {
        Random num2 = new Random();
        int randomNumber2 = num2.nextInt(max - min) + min;
        if (randomNumber2 == min) {
            return min + 1;
        } else {
            return randomNumber2;
        }
    }

    public static boolean highstorm() {
        if(randomNumber <= 9) {
            highstorm = false;
            System.out.println("there is no highstorm coming");
        }
        else {
            highstorm = true;
            System.out.println("a highstorm is approaching at rapid pace! the stormwall will hit and two minutes!");
        }
        return highstorm;
    }

    public static boolean findShelter() {

        if(randomNumber2 >=5) {
            findShelter = true;
            System.out.println("you found shelter inside the zoo, you survived");
        }
        else {
            findShelter = false;
            System.out.println("The stormwall hits you with a force like a hundred hurricanes.");
            System.out.println("your body is twisted and turned until you are almost unreconizable");
            System.out.println("your death is quick and excruciating, the stormfather spares no mercy");
        }
        return findShelter;
    }

}

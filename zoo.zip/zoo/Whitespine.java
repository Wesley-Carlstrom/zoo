
/**
 * Write a description of class Whitespine here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Whitespine extends Animal 
implements Walking
{
    public Whitespine() {
        this("a horse sized whitespine of Roshar" , "hazardous to humans and hunted by lighteyes for sport");
    }

    public Whitespine(String name, String description) {
        super(name, description);
    }

    @Override

    public String eat() {
        return("eats the unprepared lighteyes hunter");
    }

    @Override
    public String makeNoise() {
        return(" hiss ");
    }

    @Override
    public String walk() {
        return "stomps around Alethkar";
    }
}

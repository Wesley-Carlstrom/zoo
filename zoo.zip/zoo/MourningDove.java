/**
 * Write a description of class MourningDove here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class MourningDove extends Animal
        implements Flying, Walking
{
    public MourningDove()
    {
        this("Lillith", "It's called the mourning Dove because of it's woeful cry.");
    }
    
    public MourningDove(String name, String description) {
        super(name, description);
        //super calls the parent
    }
    
    @Override
    
    public String eat() {
        return "Eats insects and fruit";
    }
    
    @Override
    public String makeNoise() {
        return "Squack!";
    }
    
    @Override
    
    public String fly() {
        return "Flap...flap....flap..";
    }
    
    @Override
    
    public String walk() {
        return "clck..clck..clck";
    }
}

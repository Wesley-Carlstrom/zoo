
/**
 * Write a description of class phish here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Platypus extends Animal implements Walking, Swimming
{
    /**
     * Constructor for objects of class phish
     */
    public Platypus()
    {
        this("perpryus The platypus", " He has a PhD in nuclear fysics.");
    }
    
    public Platypus(String name, String description)
    {
        super(name, description);
    }
    @Override
    public String eat()
    {
        return "jet A-1 fuel";
    }
    @Override
    public String makeNoise()
    {
        return "rapidly ghghgh angrily";
    }
    @Override
    public String swim()
    {
       return "";
    }
    @Override
    public String walk()
    {
       return "";
    }
}

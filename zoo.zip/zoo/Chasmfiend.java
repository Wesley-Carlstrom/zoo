
/**
 * Write a description of class ChasmFiend here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Chasmfiend extends Animal
implements Walking
{
    public Chasmfiend() {
        this(" a chasmfiend of the shattered plains" , "the most feared animal in all of Roshar");
    }

    public Chasmfiend(String name, String description) {
        super(name, description);
    }

    @Override

    public String eat() {
        return("consumes remnants of plateau battles");
    }

    @Override
    public String makeNoise() {
        return("roar with unparraleled ferocity");
    }

    @Override
    public String walk() {
        return "stomp and crawl throught the chasm";
    }
}

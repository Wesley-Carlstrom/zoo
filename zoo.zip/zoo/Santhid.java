public class Santhid extends Animal
implements Swimming
{
    public Santhid() {
        this(" A santhid of the oceans" , "Rarely seen below water, if that, it has a long body with two huge eyes and many tentacals with a large shell on the top of it");
    }

    public Santhid(String name, String description) {
        super(name, description);
    }

    @Override

    public String eat() {
        return("eat small and medium sized sea creatures");
    }

    @Override
    public String makeNoise() {
        return("groans and gurgles");
    }

    @Override
    public String swim() {
        return "swim slowly andglid through the water  ";
    }
}

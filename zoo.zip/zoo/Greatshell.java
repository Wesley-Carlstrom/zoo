public class Greatshell extends Animal
implements Walking
{
    public Greatshell() {
        this(" a large crustecean" , "they bond with spren to keep from collapsing");
    }

    public Greatshell(String name, String description) {
        super(name, description);
    }

    @Override

    public String eat() {
        return("consumes a variety of fauna on Roashar");
    }

    @Override
    public String makeNoise() {
        return("chull quietly");
    }

    @Override
    public String walk() {
        return "stroll slowly";
    }
}

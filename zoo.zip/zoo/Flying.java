
/**
 * Write a description of interface flying here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public interface Flying
{
    public String fly();
}

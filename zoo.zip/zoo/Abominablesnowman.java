
/**
 * Write a description of class Snake here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Abominablesnowman extends Animal implements Walking
{
    public Abominablesnowman()
    {
        /*
         *  Call my other constructor that takes two Strings
         *  Again, this is called constructotr chaining
         */
        this("Snowy the Abominable snowman", "Lives in freezing snowy areas");
    }
    
    public Abominablesnowman(String name, String description)
    {
        /*
         * super means call something in my parent class (Animal), in this
         * case I am calling the constructor in my aprent that takes
         * two paramenters and sending in the name and description that 
         * were passed into this constructor
         */
        
        
        super(name, description);
    }
    
    @Override
    public String eat()
    {
        return "Eats people, snow, and ice";
    }
    
    @Override
    public String makeNoise()
    {
        return "BURRRRERRRRRR";
    }
    
     @Override
    public String walk()
    {
        return "Step step steppy";
    }
}

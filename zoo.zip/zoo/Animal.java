
/**
 * Abstract class animal - write a description of the class here
 *
 * @author (your name here)
 * @version (version number or date here)
 */
public abstract class Animal
{
    protected String name;
    protected String description;
    public static int numAnimals = 0;
    public Animal() {
        this("none");
    }

    public Animal(String name) {
        this(name, "none");
    }

    public Animal(String name, String description) {
        this.name = name;
        this.description = description;
        numAnimals++;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return this.name;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDescription() {
        return this.description;
    }

    @Override
    public String toString() {
        return this.name + this.description;  
    }

    public abstract String eat();
    public abstract String makeNoise();
}
